import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { CustomersPage } from "@/components/dashboard/customers-page"

export default function Customers() {
  return (
    <DashboardLayout>
      <CustomersPage />
    </DashboardLayout>
  )
}
