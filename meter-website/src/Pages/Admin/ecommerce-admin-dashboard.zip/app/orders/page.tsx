import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { OrdersPage } from "@/components/dashboard/orders-page"

export default function Orders() {
  return (
    <DashboardLayout>
      <OrdersPage />
    </DashboardLayout>
  )
}
