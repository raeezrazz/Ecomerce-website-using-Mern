"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import Image from "next/image"

const products = [
  {
    name: "Wireless Headphones",
    sales: 1234,
    revenue: "$12,340",
    image: "/placeholder.svg?height=40&width=40",
    progress: 85,
  },
  {
    name: "Smart Watch",
    sales: 987,
    revenue: "$19,740",
    image: "/placeholder.svg?height=40&width=40",
    progress: 72,
  },
  {
    name: "Laptop Stand",
    sales: 756,
    revenue: "$7,560",
    image: "/placeholder.svg?height=40&width=40",
    progress: 58,
  },
  {
    name: "USB-C Cable",
    sales: 543,
    revenue: "$2,715",
    image: "/placeholder.svg?height=40&width=40",
    progress: 41,
  },
  {
    name: "Phone Case",
    sales: 321,
    revenue: "$3,210",
    image: "/placeholder.svg?height=40&width=40",
    progress: 25,
  },
]

export function TopProducts() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Top Products</CardTitle>
        <CardDescription>Best selling products this month</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {products.map((product, index) => (
          <div key={product.name} className="flex items-center space-x-4">
            <div className="flex-shrink-0">
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={40}
                height={40}
                className="rounded-md"
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 truncate">{product.name}</p>
              <p className="text-sm text-gray-500">
                {product.sales} sales • {product.revenue}
              </p>
              <Progress value={product.progress} className="mt-2 h-2" />
            </div>
            <div className="text-sm font-medium text-gray-900">#{index + 1}</div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
