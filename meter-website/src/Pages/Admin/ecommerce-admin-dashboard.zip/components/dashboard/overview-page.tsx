"use client"

import { StatsCards } from "./stats-cards"
import { RevenueChart } from "./revenue-chart"
import { RecentOrders } from "./recent-orders"
import { TopProducts } from "./top-products"
import { CustomerInsights } from "./customer-insights"

export function OverviewPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard Overview</h1>
        <p className="mt-2 text-sm text-gray-700">Welcome back! Here's what's happening with your store today.</p>
      </div>

      <StatsCards />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <RevenueChart />
        <CustomerInsights />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <RecentOrders />
        <TopProducts />
      </div>
    </div>
  )
}
