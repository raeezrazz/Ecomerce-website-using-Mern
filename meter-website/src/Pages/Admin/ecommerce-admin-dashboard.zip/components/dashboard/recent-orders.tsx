"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

const orders = [
  {
    id: "#3210",
    customer: "Olivia Martin",
    email: "olivia@example.com",
    status: "Fulfilled",
    date: "2024-01-15",
    amount: "$42.25",
  },
  {
    id: "#3209",
    customer: "Ava Johnson",
    email: "ava@example.com",
    status: "Pending",
    date: "2024-01-14",
    amount: "$74.99",
  },
  {
    id: "#3208",
    customer: "Michael Johnson",
    email: "michael@example.com",
    status: "Shipped",
    date: "2024-01-13",
    amount: "$64.75",
  },
  {
    id: "#3207",
    customer: "Lisa Anderson",
    email: "lisa@example.com",
    status: "Fulfilled",
    date: "2024-01-12",
    amount: "$34.50",
  },
  {
    id: "#3206",
    customer: "Chris Taylor",
    email: "chris@example.com",
    status: "Cancelled",
    date: "2024-01-11",
    amount: "$89.99",
  },
]

export function RecentOrders() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Orders</CardTitle>
        <CardDescription>Latest orders from your customers</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Date</TableHead>
              <TableHead className="text-right">Amount</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell className="font-medium">{order.id}</TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="font-medium">{order.customer}</span>
                    <span className="text-sm text-muted-foreground">{order.email}</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      order.status === "Fulfilled"
                        ? "default"
                        : order.status === "Shipped"
                          ? "secondary"
                          : order.status === "Pending"
                            ? "outline"
                            : "destructive"
                    }
                  >
                    {order.status}
                  </Badge>
                </TableCell>
                <TableCell>{order.date}</TableCell>
                <TableCell className="text-right">{order.amount}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="mt-4">
          <Button variant="outline" className="w-full">
            View All Orders
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
